import { Injectable } from '@angular/core';
import { MatPaginatorIntl } from '@angular/material/paginator';

/** Libellés français du mat-paginator */
@Injectable()
export class FrPaginatorIntl extends MatPaginatorIntl {
  override itemsPerPageLabel = 'Lignes par page';
  override nextPageLabel = 'Page suivante';
  override previousPageLabel = 'Page précédente';
  override firstPageLabel = 'Première page';
  override lastPageLabel = 'Dernière page';
  override getRangeLabel = (page: number, size: number, length: number): string => {
    if (length === 0) return '0 sur 0';
    const start = page * size;
    return `${start + 1} – ${Math.min(start + size, length)} sur ${length}`;
  };
}
